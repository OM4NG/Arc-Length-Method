clc; 
syms q p;
x0  = input("Enter the initial input: ");
tol = input("Enter the value of tolerance: ");
n = input("Enter the max. number of iterations: ");
x = zeros(1,n);
x(1) = x0;
Residue(1) = 0;
fprintf("--------------------------------------------------------------------------\n");
fprintf("Iteration         Old_x               New_x               Residue\n");
fprintf("--------------------------------------------------------------------------\n");
for i = 2:n
    x(i) = x0 - fx(x0)/dfx(x0);
    Residue(i) = abs(x(i) - x(i-1));
    fprintf('%d            %d            %d            %d\n',i-1,x(i-1),x(i),Residue(i));
    if Residue(i)<=tol
        fprintf("Solution found at %d iteration = %f\n",i-1, x(i));
        X = 1:i;
        break
    end
   x0 = x(i);
end
%% Figure 1: Variation of function with iteration
figure (1)
Y = zeros(1,size(X,2));
for t = 1:size(X,2)
    Y(t) = fx(x(t));
end
plot(X,Y,"-*", 'MarkerEdgeColor','red');
title("Variation of function with iteration");
xlabel("Iteration");
ylabel("Value of function");

%% Figure 2: Variation of function with x values
xn = x(1:size(X,2));
%f = q^3 - 6*q^2 + 4*q + 12; %example for snapthrough
%f = p^3 - 0.615*p^2 + 3.993*10^(-4); %working NR Scheme example

f = atan(p);

figure (2)
plot(xn,Y,"*", 'MarkerEdgeColor' , 'red');
hold on
fplot(f)
title("Points traced by Newton-Raphson");
xlabel("x");
ylabel("F(x)");
hold on;
line(xlim, [0 0],'LineStyle','-.');
%% Figure 3: To drop tangents and show NR Scheme
x_dash = zeros(size(X,2));
for i=1:size(X,2)
    x_dash = dfx(x(i));
end
%y - y1 = m*(x - x1)
%-y1/m + x1 = x
    figure(3)
    fplot(f);
    hold on;
    title("Convergence to solution");
    xlabel("x");
    ylabel("F(x)"); 
    hold on;
    
for i =1:size(X,2)
    x_dash = dfx(x(i));
    new_x = -Y(i)/x_dash + x(i);
    line([0 0],ylim,'LineStyle', '-.');
    line(xlim, [0 0],'LineStyle','-.');
    %xlim([-2 12]);
    hold on;
    plot(x(i), Y(i), '*r', 'MarkerSize',3*i);
    hold on;
    line([x(i) new_x], [Y(i) 0],'Color','blue','LineStyle',':');
    hold on;
    line([new_x new_x], [0 fx(new_x)],'Color','black','LineStyle','--');
    hold on;   
end
%%

    