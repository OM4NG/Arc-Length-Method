function y = dfx(x)
%y = 3*x^2 - 12*x +4; %example of snapthrough 
%y = 3*x^2 - 0.33*x; %working NR scheme example
end
