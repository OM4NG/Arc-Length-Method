function y = fx(x)
%y = x^3 - 6*x^2 + 4*x + 12; %example of snapthrough
%y = x^3 - 0.615*x^2 + 3.993*10^(-4); %working NR Scheme example
end
