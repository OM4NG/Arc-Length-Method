function t =draw_circle(x_center,y_center,radius)
 %x_center and y_center are the coordinates of the center of the circle
%radius is the radius of the circle
%0.001 is the angle step
ang=0:0.001:2*pi; 
xp=radius*cos(ang);
yp=radius*sin(ang);
%%
figure(1)
plot(x_center+xp,y_center+yp);
hold on;
t = 1;
end
%%