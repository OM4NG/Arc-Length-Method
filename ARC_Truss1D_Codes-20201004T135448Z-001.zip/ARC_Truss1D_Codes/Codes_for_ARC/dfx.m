function y = dfx(a)
%performing symbolic differentiation
syms x; %symbolic variable x declared
theta_0 = pi/3; %theta_0 is the angle made with horizontal 
y = (1/((1-2*x*sin(theta_0) + x^2)^0.5) - 1)*(sin(theta_0) - x); 
%%
dy = diff(y,x); %dy give the differentiation of function with variable x
y = double(subs(dy,x,a)); %substituting the vale of x in diferentiation and calculating its value
end