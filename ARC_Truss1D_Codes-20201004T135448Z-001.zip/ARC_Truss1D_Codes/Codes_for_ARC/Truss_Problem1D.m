%{
Using "Snake-Case Notation"

     u(1) = initial assumption for position
lambda(1) = initial assumption for increment in load

psi = parameter for arc-length method...
psi = 1 for spherical and...
psi = 0 for cylindrical

max_itr = maximum number of iterations the code will run for

     delta_u = change in u
delta_lambda = change in lambda

     del_u_initial = initial assumption
del_lambda_initial = initial assumption

     del_u = del_ut + del_ubar final change in u required
del_lambda = final change in lambda required

tol = tolerance for convergence of solution

     u_dash = u + delta_u + del_u  ---->new u obtained for next iteration
lambda_dash = lambda + delta_lamda + del_lambda ---->new lambda obtained for next iteration

delta_L = radius of sphere for spherical arc length method
phase = to keep track of converged solutions
%}
%% Initializing the variables
clc;
delta_L = 0.6; %can be changed 
max_itr = 70; % can be changed 
   tol  = 10^-6; %can be changed
   psi  = 1; %spherical arc length -->cannot be changed<--
   phase = 1; %initializing the phase to denote converged solutions
      q = 1; %load vector

%% Creating the required vectors to store values
   
u = zeros(1,max_itr + 1);
delta_u = zeros(1,max_itr + 1);
u_dash = zeros(1,max_itr + 1);

func = zeros(1,max_itr+1);

lambda = zeros(1,max_itr +1);
delta_lambda = zeros(1,max_itr + 1);
lambda_dash = zeros(1,max_itr + 1);

%% Initial values for change required 

     delta_u_initial = -0.08; %can be changed
delta_lambda_initial = -0.08; %can be changed 

     del_u = 0; %del_u = del_ut + del_ubar
del_lambda = 0;

     u(1) = 5; %initial assumption
lambda(1) = 2; %initial assumption
u_dash(1) = u(1);  %for initialization
lambda_dash(1) = lambda(1); %for initialization

f_int = zeros(1,max_itr +1); %F(u)
f_ext = zeros(1,max_itr + 1); %lambda*q
residue = zeros(1,max_itr + 1); % R = F(u) - lambda*q

residue(1) = 1;
  
     delta_u(1) = 0; %for first iteration equal to 0
delta_lambda(1) = 0; %for first iteration equal to 0

theta_0 = pi/3;

%% Starting the Arc - Length procedure
syms x;
figure(1)
fplot((1/(1 - 2*x*sin(theta_0) + x^2)^0.50 - 1)*(sin(theta_0) - x))
xlabel('Displacement')
ylabel('Load')
title('Arc-Length')

hold on;
grid on;

fprintf("--------------------------------------------------------------------------\n");
fprintf("Iteration         u_dash              del_u               Residue\n");
fprintf("--------------------------------------------------------------------------\n");
for i = 1:max_itr
    if(abs(residue(i)) >= tol)
        ss = draw_circle(u(phase),lambda(phase),delta_L);
        if i == phase
                    
            delta_u(i+1) = delta_u(i) + delta_u_initial;
            u_dash(i+1) = u(i) + delta_u(i+1);
            delta_lambda(i+1) = delta_lambda(i) + delta_lambda_initial;
            lambda_dash(i+1) = lambda(i) + delta_lambda_initial;
            func(i+1) = fx(u_dash(i+1)); %include the function here
            f_int(i+1) = func(i+1);
            f_ext(i+1) = lambda_dash(i+1)*q;
            residue(i+1) = f_int(i+1) - f_ext(i+1);
            fprintf('   %d        %d        %d        %d \n',i,u_dash(i+1),double(del_u), residue(i+1));
        else
            Kt = dfx(u_dash(i)); %include function for tangent stiffnes calculation 
            del_ubar = -inv(Kt)*(func(i)-lambda_dash(i)*q);    
            del_ut = Kt\q; 
            
%% calculating del_lambda and del_u   
            alpha1 = (del_ut')*del_ut + (psi^2)*(q')*q;
            
            alpha2 = 2*(delta_u(i) + del_ubar)'*del_ut + 2*(psi^2)*delta_lambda(i)*(q')*q;
            
            alpha3 = (delta_u(i) + del_ubar)'*(delta_u(i) + del_ubar)...
                + (psi^2)*(delta_lambda(i)^2)*(q')*q - delta_L^2 ;
            
            %solve_quad is a function to solve quadratic equations
            [del_l1,del_l2] = solve_quad(alpha1,alpha2,alpha3); %solve_quad introduced
           
            del_u1 = del_ubar + del_l1*del_ut;
            del_u2 = del_ubar + del_l2*del_ut;
            
            Dot1 = (delta_u(i)+del_u1)'*delta_u(i) + (psi^2)*delta_lambda(i)*(delta_lambda(i)+del_l1)*((q')*q);
            Dot2 = (delta_u(i)+del_u2)'*delta_u(i) + (psi^2)*delta_lambda(i)*(delta_lambda(i)+del_l2)*((q')*q);
            
%% Checking larger between Dot1 and Dot2 to decide which solution of quadratic equation to keep
            if Dot1 >= Dot2
                del_lambda = del_l1;
            else
                del_lambda = del_l2;            
            end
            
            del_u = del_ubar + del_lambda*del_ut;
            
%% updating u_new(i+1)    
            delta_u(i+1) = delta_u(i) + del_u;
            u_dash(i+1) = del_u + u_dash(i);
            delta_lambda(i+1) = delta_lambda(i) + del_lambda;
            lambda_dash(i+1) = del_lambda + lambda_dash(i);
        
            func(i+1) = fx(u_dash(i+1)); %include function here
            f_int(i+1) = func(i+1);
            f_ext(i+1) = lambda_dash(i+1)*q;
            residue(i+1) = f_int(i+1) - f_ext(i+1);
%% If the solution does not converge print and continue            
            
            if abs(residue(i+1))>=tol
                fprintf('   %d        %d         %d         %d \n',i,u_dash(i+1),double(del_u),residue(i+1));
                
            else % when solution converges mark the phase and move on to next phase
                fprintf('   %d        %d         %d         %d \n',i,u_dash(i+1),double(del_u),residue(i+1));
                
                %%initializing values for the next phase of solution
                residue(i+1)=1;
                func(i+1) = 0;
                u(i+1) = u_dash(i+1);
                lambda(i+1) = lambda_dash(i+1);
                delta_u(i+1) = 0;
                delta_u_initial = -0.01;
                del_lambda= 0;
                del_u = 0;
                delta_lambda(i+1) = 0;
                delta_lambda_initial = -0.01;     
                phase = i+1; %phase increased as solution converges
           end 
        end
     
%% Figure for plotting the points traced by Arc-Length method
        
        if i>=2
        
        figure(1) %naming as figure 1 to continue the plot of circle on same figure
        fplot((1/(1 - 2*x*sin(theta_0) + x^2)^0.50 - 1)*(sin(theta_0) - x)); hold on; %plotting the function and using hold on to draw circle 
        
        plot(u_dash(1),lambda_dash(1),'ro'); hold on 
        hold on
        plot(u_dash(i),lambda_dash(i),'bo'); hold on 
        
        %vertical line joining internal and external force
        line([u_dash(i+1) u_dash(i+1)],[f_int(i+1) f_ext(i+1)]) 
        %{ 
           plotting u_dash i.e. new displacement and f_int that is force
           on force displacment curve
        %}
        
        plot(u_dash(i+1),f_int(i+1),'ro'); hold on
        
        %{
        Plotting the line from old displacment and old external force to
        new displacment and new external force i.e. 
        from (u_dash(i),f_ext(i)) to (u_dash(i+1),f_ext(i+1))
        %}
        
        line([u_dash(i) u_dash(i+1)],[f_ext(i) f_ext(i+1)],'LineStyle','-');hold on;
        line([u_dash(i) u_dash(i+1)],[f_int(i) f_ext(i+1)],'LineStyle','--');hold on%slant line
     

        
        %{
        syms t;
        y = (1/(1 - 2*x*sin(theta_0) + x^2)^0.50 - 1)*(sin(theta_0) - x); %write the function def here
        %-->
        figure(2)
        fplot(y);
        line(xlim, [0 0],'LineStyle','-.');
        line([0 0], ylim,'LineStyle','-.');
        xlabel('Displacement');
        ylabel('Load');
        title('Convergence and Path traced by Arc-Length');
        set(gca,'FontSize',18);
        hold on;
        %load vs displacement curve
        plot(u_dash(i),f_int(i),"-*", 'MarkerEdgeColor','red'); 
        hold on;
        %}
        end
   end
end