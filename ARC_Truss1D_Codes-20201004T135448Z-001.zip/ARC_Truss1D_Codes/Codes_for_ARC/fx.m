function y = fx(x)
theta_0 = pi/3; %theta_0 is the angle made with horizontal 
y = (1/(1 - 2*x*sin(theta_0) + x^2)^0.50 - 1)*(sin(theta_0) - x); %function definition
end
