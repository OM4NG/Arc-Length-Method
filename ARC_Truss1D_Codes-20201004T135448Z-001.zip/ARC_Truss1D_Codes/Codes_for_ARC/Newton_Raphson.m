clc; 
syms p; %symbolic declaration of variable p

%x0 = user input for initial assumption
%tl = required tolerance for breaking the loop
%n = max number of iterations permitted

x0  = input("Enter the initial input: ");
tol = input("Enter the value of tolerance: ");
n = input("Enter the max. number of iterations: ");
%%
%x = to store the x values
%theta_0 is the angle made with horizontal 

x = zeros(1,n);
theta_0 = pi/3;
x(1) = x0;

%residue is basically the error at each iteration

Residue(1) = 0;
%% Starting the Newton-Raphson Scheme

fprintf("--------------------------------------------------------------------------\n");
fprintf("Iteration         Old_x               New_x               Residue\n");
fprintf("--------------------------------------------------------------------------\n");
for i = 2:n
    x(i) = x0 - fx(x0)/dfx(x0);
    Residue(i) = abs(x(i) - x(i-1));
    fprintf('%d            %d            %d            %d\n',i-1,x(i-1),x(i),Residue(i));
    if Residue(i)<=tol %condition for breaking the loop and solution convergence
        fprintf("Solution found at %d iteration = %f\n",i-1, x(i));
        X = 1:i;
        break
    end
   x0 = x(i);
end
%% Figure 1: Variation of function with iteration

figure (1)
Y = zeros(1,size(X,2));
for t = 1:size(X,2)
    Y(t) = fx(x(t));
end
plot(X,Y,"-*", 'MarkerEdgeColor','red');
title("Variation of function with iteration");
xlabel("Iteration");
ylabel("Value of function");

%% Figure 2: Variation of function with x values

xn = x(1:size(X,2));
f = (1/(1 - 2*p*sin(theta_0) + p^2)^0.50 - 1)*(sin(theta_0) - p);

figure (2)
plot(xn,Y,"*", 'MarkerEdgeColor' , 'red');
hold on
fplot(f)
title("Points traced by Newton-Raphson");
xlabel("Displacement");
ylabel("Load");
hold on;
line(xlim, [0 0],'LineStyle','-.');
%% Figure 3: To drop tangents and show NR Scheme

x_dash = zeros(size(X,2));
for i=1:size(X,2)
    x_dash = dfx(x(i));
end
%y - y1 = m*(x - x1)
%-y1/m + x1 = x
    figure(3)
    fplot(f);
    hold on;
    title("Convergence to solution");
    xlabel("Displacement");
    ylabel("Load"); 
    hold on;
    
for i =1:size(X,2)
    x_dash = dfx(x(i));
    new_x = -Y(i)/x_dash + x(i);
    line([0 0],ylim,'LineStyle', '-.'); %vertical y axis
    line(xlim, [0 0],'LineStyle','-.'); %horizontal x axis
    hold on;
    plot(x(i), Y(i), '*r', 'MarkerSize',3*i); %plotting the point (x,Y)
    hold on;
    line([x(i) new_x], [Y(i) 0],'Color','blue','LineStyle',':'); %line intersect with x axis
    hold on;
    line([new_x new_x], [0 fx(new_x)],'Color','black','LineStyle','--'); %perpendicular to function
    hold on;   
end
%%

    