function [x1,x2] = solve_quad(a,b,c)
        %D = discriminant of quadratic equation
        %a is coefficient of x square
        %b is coefficient of x
        %c is constant
    D = b*b - 4*a*c;
    if(D<0)
        %if D<0 we ignore that and consider linear equation
        %this is one drawback in arc length
        x1 = -b/(2*a);
        x2 = -b/(2*a);
    else
        %calculating roots of the equation by quadratic formula
        x1 = (-b + sqrt(D))/(2*a);
        x2 = (-b - sqrt(D))/(2*a);
    end
end    
